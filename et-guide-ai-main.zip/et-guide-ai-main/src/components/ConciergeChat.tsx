import { useState, useRef, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Send, Volume2, VolumeX, Sparkles } from "lucide-react";
import ReactMarkdown from "react-markdown";
import { Button } from "@/components/ui/button";
import VoiceButton from "./VoiceButton";
import { useSpeechRecognition } from "@/hooks/useSpeechRecognition";
import { useSpeechSynthesis } from "@/hooks/useSpeechSynthesis";
import { streamChat } from "@/lib/streamChat";
import { extractProfile } from "@/lib/profileExtractor";
import type { UserProfile } from "./UserProfilePanel";

type Message = { role: "user" | "assistant"; content: string };

interface ConciergeChatProps {
  onProfileUpdate: (profile: UserProfile) => void;
  onConversationStart: () => void;
}

const WELCOME_MESSAGE = `Welcome to **Economic Times AI Concierge**! 🙏

I'm your personal financial navigator — here to understand your complete financial world and guide you to the right ET products, tools, and partner services.

In just a few minutes, I'll help you discover:

- 📊 The right **investment tools** and market insights for your style
- 🎯 **Goal-based pathways** — retirement, tax saving, wealth building
- 💳 **Exclusive partner offers** — credit cards, loans, insurance
- 🔍 **Portfolio gaps** you might not know about

**What's your name, and how would you describe your investment journey so far?**`;

const getAdaptivePrompts = (messageCount: number, profile: Partial<UserProfile>): string[] => {
  if (messageCount <= 1) {
    return [
      "I'm new to investing",
      "I'm an experienced trader",
      "Help me plan my taxes",
      "I want to grow my wealth",
    ];
  }
  if (messageCount <= 3 && !profile.riskAppetite) {
    return [
      "I prefer safe investments",
      "I'm okay with moderate risk",
      "I'm aggressive with investments",
    ];
  }
  if (messageCount <= 5 && !profile.goals?.length) {
    return [
      "Retirement planning",
      "Tax saving strategies",
      "Building an emergency fund",
      "Home purchase planning",
    ];
  }
  if (messageCount > 4 && !profile.interests?.length) {
    return [
      "Show me my recommendations",
      "Tell me about ET Prime",
      "Check my portfolio health",
      "Explore credit cards & loans",
    ];
  }
  return [];
};

const ConciergeChat = ({ onProfileUpdate, onConversationStart }: ConciergeChatProps) => {
  const [messages, setMessages] = useState<Message[]>([
    { role: "assistant", content: WELCOME_MESSAGE },
  ]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [voiceEnabled, setVoiceEnabled] = useState(false);
  const [currentProfile, setCurrentProfile] = useState<Partial<UserProfile>>({});
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const { speak, stop: stopSpeaking } = useSpeechSynthesis();

  const handleVoiceResult = useCallback((text: string) => {
    setInput(text);
  }, []);

  const { isListening, toggleListening, isSupported } = useSpeechRecognition(handleVoiceResult);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const updateProfile = useCallback(
    (text: string) => {
      const data = extractProfile(text);
      if (Object.keys(data).length > 0) {
        setCurrentProfile((prev) => ({ ...prev, ...data }));
        onProfileUpdate(data);
      }
    },
    [onProfileUpdate]
  );

  const sendMessage = async (text: string) => {
    if (!text.trim() || isLoading) return;

    onConversationStart();
    const userMsg: Message = { role: "user", content: text.trim() };
    const newMessages = [...messages, userMsg];
    setMessages(newMessages);
    setInput("");
    setIsLoading(true);

    updateProfile(text);

    let assistantSoFar = "";

    const upsertAssistant = (chunk: string) => {
      assistantSoFar += chunk;
      setMessages((prev) => {
        const last = prev[prev.length - 1];
        if (last?.role === "assistant" && prev.length > newMessages.length) {
          return prev.map((m, i) => (i === prev.length - 1 ? { ...m, content: assistantSoFar } : m));
        }
        return [...prev.slice(0, newMessages.length), { role: "assistant", content: assistantSoFar }];
      });
    };

    try {
      await streamChat({
        messages: newMessages.map((m) => ({ role: m.role, content: m.content })),
        onDelta: upsertAssistant,
        onDone: () => {
          setIsLoading(false);
          updateProfile(assistantSoFar);
          if (voiceEnabled && assistantSoFar) {
            speak(assistantSoFar.replace(/[*#_`]/g, "").substring(0, 400));
          }
        },
        onError: (err) => {
          setIsLoading(false);
          setMessages((prev) => [...prev, { role: "assistant", content: `I'm sorry — ${err}` }]);
        },
      });
    } catch {
      setIsLoading(false);
      setMessages((prev) => [
        ...prev,
        { role: "assistant", content: "I'm sorry, I encountered an issue. Please try again." },
      ]);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage(input);
    }
  };

  const quickPrompts = getAdaptivePrompts(messages.length, currentProfile);

  return (
    <div className="flex flex-col flex-1 min-h-0">
      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-4 py-6 space-y-4">
        <AnimatePresence initial={false}>
          {messages.map((msg, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
              className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
            >
              <div
                className={`max-w-[85%] md:max-w-[70%] rounded-2xl px-4 py-3 text-sm leading-relaxed ${
                  msg.role === "user"
                    ? "gradient-gold text-primary-foreground rounded-br-md"
                    : "bg-secondary text-secondary-foreground rounded-bl-md"
                }`}
              >
                {msg.role === "assistant" ? (
                  <div className="prose prose-sm prose-invert max-w-none [&_p]:mb-2 [&_ul]:mb-2 [&_li]:mb-0.5 [&_strong]:text-foreground">
                    <ReactMarkdown>{msg.content}</ReactMarkdown>
                  </div>
                ) : (
                  <p>{msg.content}</p>
                )}
              </div>
            </motion.div>
          ))}
        </AnimatePresence>

        {isLoading && messages[messages.length - 1]?.role !== "assistant" && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex justify-start">
            <div className="bg-secondary rounded-2xl rounded-bl-md px-4 py-3 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-primary animate-pulse" />
              <span className="text-sm text-muted-foreground">Thinking...</span>
            </div>
          </motion.div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Adaptive quick prompts */}
      {quickPrompts.length > 0 && !isLoading && (
        <div className="px-4 pb-3 flex flex-wrap gap-2">
          {quickPrompts.map((prompt) => (
            <button
              key={prompt}
              onClick={() => sendMessage(prompt)}
              className="text-xs px-3 py-1.5 rounded-full border border-border text-muted-foreground hover:text-foreground hover:border-primary/40 transition-colors"
            >
              {prompt}
            </button>
          ))}
        </div>
      )}

      {/* Input */}
      <div className="p-4 border-t border-border bg-card/50">
        <div className="flex items-end gap-2 bg-secondary/50 rounded-xl border border-border focus-within:border-primary/40 transition-colors p-2">
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Type your message or use voice..."
            rows={1}
            className="flex-1 bg-transparent text-sm text-foreground placeholder:text-muted-foreground resize-none outline-none px-2 py-1.5 max-h-24"
          />
          <div className="flex items-center gap-1">
            <button
              onClick={() => {
                setVoiceEnabled(!voiceEnabled);
                if (voiceEnabled) stopSpeaking();
              }}
              className={`p-2 rounded-lg transition-colors ${
                voiceEnabled ? "text-primary" : "text-muted-foreground hover:text-foreground"
              }`}
              title={voiceEnabled ? "Disable voice responses" : "Enable voice responses"}
            >
              {voiceEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            </button>
            {isSupported && <VoiceButton isListening={isListening} onToggle={toggleListening} />}
            <Button
              variant="gold"
              size="icon"
              onClick={() => sendMessage(input)}
              disabled={!input.trim() || isLoading}
              className="rounded-lg h-9 w-9"
            >
              <Send className="w-4 h-4" />
            </Button>
          </div>
        </div>
        <p className="text-[10px] text-text-tertiary mt-2 text-center">
          ET AI Concierge • Your personal guide to the Economic Times ecosystem
        </p>
      </div>
    </div>
  );
};

export default ConciergeChat;
