import { Sparkles } from "lucide-react";

const ETHeader = () => {
  return (
    <header className="flex items-center justify-between px-6 py-4 border-b border-border bg-card/80 backdrop-blur-sm">
      <div className="flex items-center gap-3">
        <div className="gradient-gold w-9 h-9 rounded-lg flex items-center justify-center">
          <span className="font-display font-bold text-lg text-primary-foreground">ET</span>
        </div>
        <div>
          <h1 className="font-display text-lg font-semibold text-foreground leading-tight">
            Economic Times
          </h1>
          <p className="text-xs text-muted-foreground">AI Concierge</p>
        </div>
      </div>
      <div className="flex items-center gap-2 text-sm text-muted-foreground">
        <Sparkles className="w-4 h-4 text-primary" />
        <span>Powered by AI</span>
      </div>
    </header>
  );
};

export default ETHeader;
