import { motion, AnimatePresence } from "framer-motion";
import {
  User, Target, TrendingUp, Shield, BookOpen, Calendar, CreditCard,
  BarChart3, Clock, Wallet, Briefcase, Zap, GraduationCap, Home, Heart
} from "lucide-react";
import RecommendationCard from "./RecommendationCard";

export interface UserProfile {
  name?: string;
  investorType?: string;
  goals?: string[];
  riskAppetite?: string;
  interests?: string[];
  incomeRange?: string;
  investmentHorizon?: string;
}

interface UserProfilePanelProps {
  profile: UserProfile;
  hasStarted: boolean;
}

type Rec = {
  title: string;
  description: string;
  icon: typeof User;
  tag?: string;
  matchScore?: number;
};

function getSmartRecommendations(profile: UserProfile): Rec[] {
  const recs: Rec[] = [];
  const { goals = [], interests = [], investorType, riskAppetite, incomeRange } = profile;

  const isBeginnerOrNew = investorType === "Beginner Investor";
  const isTrader = investorType === "Active Trader" || investorType === "Experienced Investor";
  const isHNI = incomeRange === "₹5L+/month" || incomeRange === "₹3L-5L/month";
  const wantsTax = goals.includes("Tax Planning");
  const wantsRetirement = goals.includes("Retirement");
  const wantsWealth = goals.includes("Wealth Building");
  const wantsInsurance = goals.includes("Insurance");
  const wantsHome = goals.includes("Home Purchase");
  const wantsDebt = goals.includes("Debt Management");

  // Always recommend Portfolio Analyser if they have any investment context
  if (isTrader || wantsWealth || interests.length > 0) {
    recs.push({
      title: "ET Portfolio Analyser",
      description: "AI-powered health check: diversification gaps, tax-loss harvesting, rebalancing alerts",
      icon: BarChart3,
      tag: "Recommended",
      matchScore: 95,
    });
  }

  if (isBeginnerOrNew) {
    recs.push({
      title: "ET Masterclass",
      description: "Start your journey with structured courses from market experts",
      icon: GraduationCap,
      tag: "Start Here",
      matchScore: 90,
    });
  }

  if (isTrader || interests.includes("IPOs")) {
    recs.push({
      title: "ET Markets Premium",
      description: "Real-time alerts, advanced screeners, IPO tracking & portfolio dashboard",
      icon: TrendingUp,
      tag: isTrader ? "For You" : undefined,
      matchScore: 88,
    });
  }

  if (wantsTax || interests.includes("ELSS") || interests.includes("NPS")) {
    recs.push({
      title: "ET Wealth Tax Optimizer",
      description: "Section 80C/80D planner, ELSS vs PPF comparison, HRA calculator",
      icon: Shield,
      tag: "Save ₹46,800+",
      matchScore: 92,
    });
  }

  if (wantsRetirement) {
    recs.push({
      title: "Retirement Pathway",
      description: "NPS guide → Corpus calculator → ET Prime retirement insights",
      icon: Clock,
      tag: "Pathway",
      matchScore: 85,
    });
  }

  // ET Prime for serious readers / HNIs
  recs.push({
    title: "ET Prime",
    description: "Exclusive deep-dives, earnings analysis, and expert columns",
    icon: BookOpen,
    tag: isHNI ? "Premium" : "Popular",
    matchScore: isHNI ? 90 : 75,
  });

  if (wantsInsurance) {
    recs.push({
      title: "Insurance Review",
      description: "Compare term life, health & critical illness plans via ET partners",
      icon: Heart,
      tag: "Protection",
      matchScore: 82,
    });
  }

  if (wantsHome || interests.includes("Loans")) {
    recs.push({
      title: "Home Loan Concierge",
      description: "Compare rates, check eligibility, get ET-exclusive processing priority",
      icon: Home,
      tag: "Marketplace",
      matchScore: 80,
    });
  }

  if (interests.includes("Credit Cards") || wantsDebt) {
    recs.push({
      title: "Credit Card Finder",
      description: "Premium cards with cashback, travel rewards & zero annual fee options",
      icon: CreditCard,
      tag: "Exclusive",
      matchScore: 78,
    });
  }

  if (isHNI) {
    recs.push({
      title: "ET Wealth Summit",
      description: "Exclusive invite to India's premier wealth management conference",
      icon: Calendar,
      tag: "VIP",
      matchScore: 86,
    });
  }

  // ET Wealth as general fallback
  if (!wantsTax && !wantsRetirement) {
    recs.push({
      title: "ET Wealth",
      description: "Personal finance guides, MF recommendations & investment planning",
      icon: Wallet,
      matchScore: 70,
    });
  }

  // Sort by match score, take top 6
  return recs
    .sort((a, b) => (b.matchScore || 0) - (a.matchScore || 0))
    .slice(0, 6);
}

const defaultRecommendations: Rec[] = [
  { title: "ET Prime", description: "Exclusive stories, deep analysis & expert opinions", icon: BookOpen, tag: "Popular" },
  { title: "ET Markets", description: "Real-time market data, portfolio tracking & alerts", icon: BarChart3 },
  { title: "ET Wealth", description: "Personal finance, tax planning & investment guides", icon: TrendingUp },
  { title: "ET Masterclass", description: "Learn from industry leaders & market experts", icon: GraduationCap },
  { title: "Financial Services", description: "Credit cards, loans, insurance via ET partners", icon: CreditCard },
  { title: "ET Portfolio Analyser", description: "AI-powered portfolio health check & rebalancing", icon: Shield },
];

const ProfileBadge = ({ label, value }: { label: string; value: string }) => (
  <div className="flex flex-col gap-0.5">
    <span className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</span>
    <span className="text-xs font-medium text-foreground">{value}</span>
  </div>
);

const UserProfilePanel = ({ profile, hasStarted }: UserProfilePanelProps) => {
  const hasProfileData = profile.name || profile.investorType || (profile.goals && profile.goals.length > 0);
  const recs = hasProfileData ? getSmartRecommendations(profile) : defaultRecommendations;

  return (
    <aside className="w-full lg:w-80 xl:w-96 border-l border-border bg-card/50 flex flex-col overflow-y-auto">
      <div className="p-5 border-b border-border">
        <h3 className="font-display text-base font-semibold text-foreground mb-1">Your Profile</h3>
        <p className="text-xs text-muted-foreground">Built from our conversation</p>
      </div>

      {/* Profile Summary */}
      <div className="p-5 border-b border-border">
        <AnimatePresence mode="wait">
          {hasStarted && profile.name ? (
            <motion.div key="profile" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full gradient-gold flex items-center justify-center">
                  <User className="w-5 h-5 text-primary-foreground" />
                </div>
                <div>
                  <p className="font-sans font-semibold text-sm text-foreground">{profile.name}</p>
                  {profile.investorType && (
                    <p className="text-xs text-primary">{profile.investorType}</p>
                  )}
                </div>
              </div>

              {/* Quick stats grid */}
              <div className="grid grid-cols-2 gap-3 p-3 rounded-lg bg-secondary/50">
                {profile.riskAppetite && <ProfileBadge label="Risk" value={profile.riskAppetite} />}
                {profile.incomeRange && <ProfileBadge label="Income" value={profile.incomeRange} />}
                {profile.investmentHorizon && <ProfileBadge label="Horizon" value={profile.investmentHorizon} />}
                {profile.interests && profile.interests.length > 0 && (
                  <ProfileBadge label="Focus" value={profile.interests.slice(0, 2).join(", ")} />
                )}
              </div>

              {profile.goals && profile.goals.length > 0 && (
                <div>
                  <p className="text-xs text-muted-foreground mb-1.5 flex items-center gap-1">
                    <Target className="w-3 h-3" /> Goals
                  </p>
                  <div className="flex flex-wrap gap-1.5">
                    {profile.goals.map((g) => (
                      <span key={g} className="text-[11px] px-2 py-1 rounded-full bg-secondary text-secondary-foreground">
                        {g}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </motion.div>
          ) : (
            <motion.div key="empty" className="text-center py-4">
              <div className="w-12 h-12 rounded-full bg-secondary mx-auto mb-3 flex items-center justify-center">
                <User className="w-6 h-6 text-muted-foreground" />
              </div>
              <p className="text-xs text-muted-foreground">
                Start a conversation to build your profile
              </p>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Recommendations */}
      <div className="p-5 flex-1">
        <div className="flex items-center justify-between mb-3">
          <h4 className="font-display text-sm font-semibold text-foreground">
            {hasProfileData ? "Personalized for You" : "Recommended for You"}
          </h4>
          {hasProfileData && (
            <span className="text-[10px] px-2 py-0.5 rounded-full bg-primary/15 text-primary font-medium flex items-center gap-1">
              <Zap className="w-2.5 h-2.5" /> AI-Matched
            </span>
          )}
        </div>
        <div className="space-y-2.5">
          {recs.map((rec, i) => (
            <RecommendationCard key={rec.title} {...rec} index={i} />
          ))}
        </div>
      </div>
    </aside>
  );
};

export default UserProfilePanel;
