import { Mic, MicOff } from "lucide-react";
import { Button } from "@/components/ui/button";

interface VoiceButtonProps {
  isListening: boolean;
  onToggle: () => void;
}

const VoiceButton = ({ isListening, onToggle }: VoiceButtonProps) => {
  return (
    <Button
      variant="ghost"
      size="icon"
      onClick={onToggle}
      className={`relative rounded-full transition-all ${
        isListening
          ? "text-primary bg-primary/10"
          : "text-muted-foreground hover:text-foreground"
      }`}
      title={isListening ? "Stop listening" : "Start voice input"}
    >
      {isListening && (
        <span className="absolute inset-0 rounded-full border-2 border-primary animate-voice-pulse" />
      )}
      {isListening ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
    </Button>
  );
};

export default VoiceButton;
