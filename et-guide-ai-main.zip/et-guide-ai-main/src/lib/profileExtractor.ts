import type { UserProfile } from "@/components/UserProfilePanel";

export function extractProfile(text: string): Partial<UserProfile> {
  const profile: Partial<UserProfile> = {};

  // Name extraction
  const nameMatch = text.match(
    /(?:my name is|i'm|i am|call me|this is)\s+([A-Z][a-z]+(?:\s[A-Z][a-z]+)?)/i
  );
  if (nameMatch) profile.name = nameMatch[1];

  // Goals
  const goals: string[] = [];
  if (/tax\s*(sav|plan|optim)/i.test(text)) goals.push("Tax Planning");
  if (/retir/i.test(text)) goals.push("Retirement");
  if (/wealth|grow|compound/i.test(text)) goals.push("Wealth Building");
  if (/mutual fund|mf|sip/i.test(text)) goals.push("Mutual Funds");
  if (/stock|trad|equity|ipo/i.test(text)) goals.push("Stock Trading");
  if (/child|kid|education/i.test(text)) goals.push("Child's Education");
  if (/home|house|property|real estate/i.test(text)) goals.push("Home Purchase");
  if (/insurance|term plan|health cover/i.test(text)) goals.push("Insurance");
  if (/debt|loan|emi/i.test(text)) goals.push("Debt Management");
  if (/emergency fund|rainy day/i.test(text)) goals.push("Emergency Fund");
  if (goals.length) profile.goals = goals;

  // Investor type
  if (/beginner|new|start|first.time|novice/i.test(text))
    profile.investorType = "Beginner Investor";
  else if (/experienc|advanced|profession|season/i.test(text))
    profile.investorType = "Experienced Investor";
  else if (/passive|long.term|buy.and.hold/i.test(text))
    profile.investorType = "Passive Investor";
  else if (/active|day.trad|swing/i.test(text))
    profile.investorType = "Active Trader";

  // Risk appetite
  if (/conservative|safe|low risk|risk.averse|cautious/i.test(text))
    profile.riskAppetite = "Conservative";
  else if (/moderate|balanced|medium risk/i.test(text))
    profile.riskAppetite = "Moderate";
  else if (/aggressive|high risk|growth.orient/i.test(text))
    profile.riskAppetite = "Aggressive";

  // Income range
  if (/₹?\s*5\s*l(akh)?.*above|₹?\s*5\s*l\+|above\s*5\s*l/i.test(text))
    profile.incomeRange = "₹5L+/month";
  else if (/₹?\s*3.*5\s*l/i.test(text)) profile.incomeRange = "₹3L-5L/month";
  else if (/₹?\s*1.*3\s*l/i.test(text)) profile.incomeRange = "₹1L-3L/month";
  else if (/₹?\s*50.*1\s*l/i.test(text)) profile.incomeRange = "₹50K-1L/month";
  else if (/₹?\s*25.*50/i.test(text)) profile.incomeRange = "₹25K-50K/month";

  // Investment horizon
  if (/short.term|less than.*year|<\s*1/i.test(text))
    profile.investmentHorizon = "Short-term (<1yr)";
  else if (/medium.term|1.*5\s*year|mid.term/i.test(text))
    profile.investmentHorizon = "Medium (1-5yr)";
  else if (/long.term|5.*year|10.*year|decades/i.test(text))
    profile.investmentHorizon = "Long-term (5yr+)";

  // Interests
  const interests: string[] = [];
  if (/ipo|listing/i.test(text)) interests.push("IPOs");
  if (/crypto|bitcoin|web3/i.test(text)) interests.push("Crypto");
  if (/gold|commodity/i.test(text)) interests.push("Commodities");
  if (/real estate|reit/i.test(text)) interests.push("Real Estate");
  if (/fd|fixed deposit/i.test(text)) interests.push("Fixed Deposits");
  if (/nps|pension/i.test(text)) interests.push("NPS");
  if (/ppf|provident/i.test(text)) interests.push("PPF");
  if (/elss|tax.sav.*fund/i.test(text)) interests.push("ELSS");
  if (/credit card/i.test(text)) interests.push("Credit Cards");
  if (/loan|mortgage/i.test(text)) interests.push("Loans");
  if (interests.length) profile.interests = interests;

  return profile;
}
