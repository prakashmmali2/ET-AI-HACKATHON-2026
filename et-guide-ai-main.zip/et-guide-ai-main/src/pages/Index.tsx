import { useState, useCallback } from "react";
import ETHeader from "@/components/ETHeader";
import ConciergeChat from "@/components/ConciergeChat";
import UserProfilePanel, { type UserProfile } from "@/components/UserProfilePanel";

const Index = () => {
  const [profile, setProfile] = useState<UserProfile>({});
  const [hasStarted, setHasStarted] = useState(false);

  const handleProfileUpdate = useCallback((data: Partial<UserProfile>) => {
    setProfile((prev) => ({
      ...prev,
      ...data,
      goals: data.goals ? [...(prev.goals || []), ...data.goals.filter((g) => !(prev.goals || []).includes(g))] : prev.goals,
    }));
  }, []);

  return (
    <div className="flex flex-col h-screen bg-background">
      <ETHeader />
      <div className="flex flex-1 min-h-0">
        <main className="flex-1 flex flex-col min-h-0">
          <ConciergeChat
            onProfileUpdate={handleProfileUpdate}
            onConversationStart={() => setHasStarted(true)}
          />
        </main>
        <div className="hidden lg:flex">
          <UserProfilePanel profile={profile} hasStarted={hasStarted} />
        </div>
      </div>
    </div>
  );
};

export default Index;
